[![SmartLearning][smartlearning-img]][smartlearning] 

Koden i dette repository bruges som undervisningsmateriale hos [SmartLearning].

Læs opgavebeskrivelsen på faget.

**Uddannelse:** [Diplom i softwareudvikling] | **Fag**: [Udvikling af store systemer] | **Forfatter**: [klangborg]



[smartlearning-img]: https://avatars.githubusercontent.com/u/89007769?s=200&u=a9050068e13b10e71a684e6789e1ec757f93e07c&v=4
[smartlearning]: https://smartlearning.dk
[Diplom i softwareudvikling]: https://www.smartlearning.dk/diplomuddannelser/diplom-i-softwareudvikling
[Udvikling af store systemer]: https://www.smartlearning.dk/diplomuddannelser/diplom-i-softwareudvikling/udvikling-store-systemer
[Systemintegration]: https://www.smartlearning.dk/diplomuddannelser/diplom-i-softwareudvikling/systemintegration
[klangborg]: https://github.com/klangborg
